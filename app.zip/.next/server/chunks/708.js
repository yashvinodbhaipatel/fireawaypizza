exports.id=708,exports.ids=[708],exports.modules={6371:(e,r,t)=>{Promise.resolve().then(t.bind(t,5821)),Promise.resolve().then(t.bind(t,7541)),Promise.resolve().then(t.bind(t,6566)),Promise.resolve().then(t.bind(t,1721)),Promise.resolve().then(t.bind(t,2248))},3534:(e,r,t)=>{Promise.resolve().then(t.t.bind(t,2994,23)),Promise.resolve().then(t.t.bind(t,6114,23)),Promise.resolve().then(t.t.bind(t,9727,23)),Promise.resolve().then(t.t.bind(t,9671,23)),Promise.resolve().then(t.t.bind(t,1868,23)),Promise.resolve().then(t.t.bind(t,4759,23))},3162:(e,r,t)=>{"use strict";t.d(r,{OG:()=>i,Rm:()=>o,mu:()=>d});var s=t(326),a=t(7577);let o=(0,a.createContext)(null),d=()=>{let e=(0,a.useContext)(o);if(!e)throw Error("useCartUpdateContext must be used within a CartUpdateProvider");return e},i=({children:e})=>{let[r,t]=(0,a.useState)(!1);return s.jsx(o.Provider,{value:{updateCart:r,setUpdateCart:t},children:e})}},4699:(e,r,t)=>{"use strict";t.d(r,{Z:()=>m});var s=t(3185);let a="https://api-ap-south-1.hygraph.com/v2/clwhb571f030d06uw44asen0r/master";console.log("NEXT_PUBLIC_BACKEND_API_URL:",a);let o=async()=>{let e=(0,s.Ps)`
    query Categories {
      categories(first: 50) {
        id
        slug
        name
        icon {
          url
        }
      }
    }
  `;return await (0,s.WY)(a,e)},d=async e=>{let r=(0,s.Ps)`
    query GetFood($category: String!) {
      bestSellings(where: { categories_some: { slug: $category } }) {
        aboutUs
        banner {
          url
        }
        categories {
          name
        }
        id
        name
        foodType
        slug
      }
    }
  `;return await (0,s.WY)(a,r,{category:e})},i=async e=>{let r=(0,s.Ps)`
    query FoodDetail($foodSlug: String!) {
      bestSelling(where: { slug: $foodSlug }) {
        aboutUs
        foodType
        banner {
          url
        }
        categories {
          name
        }
        id
        name
        slug
        menu {
          ... on Menu {
            id
            categories
            menuItem {
              ... on MenuItem {
                id
                name
                price
                productImage {
                  url
                }
                description
                addons {
                  ... on Addons {
                    id
                    name
                    price
                  }
                }
              }
            }
          }
        }
      }
    }
  `;return await (0,s.WY)(a,r,{foodSlug:e})},n=async e=>{let r=(0,s.Ps)`
    mutation AddToCart(
      $email: String!,
      $price: Float!,
      $productDescription: String!,
      $productImage: String!,
      $productName: String!,
      $addons: String!,
      $addonsPrice: Float!
    ) {
      createUserCart(
        data: {
          email: $email,
          price: $price,
          productDescription: $productDescription,
          productImage: $productImage,
          productName: $productName,
          addons: $addons,
          addonsPrice: $addonsPrice
        }
      ) {
        id
        addons
        addonsPrice
      }
      publishManyUserCarts(to: PUBLISHED) {
        count
      }
    }
  `,t={email:e.email,price:e.price,productDescription:e.description,productImage:e.productImage,productName:e.name,addons:e.addons,addonsPrice:e.addonsPrice};return await (0,s.WY)(a,r,t)},l=async e=>{let r=(0,s.Ps)`
    query getUserCart($email: String!) {
      userCarts(where: { email: $email }) {
        id
        email
        price
        productDescription
        addons
        addonsPrice
        productImage
        productName
      }
    }
  `;return await (0,s.WY)(a,r,{email:e})},c=(0,s.Ps)`
  mutation RemoveFromCart($id: ID!) {
    deleteUserCart(where: { id: $id }) {
      id
    }
  }
`,m={GetCategory:o,getFood:d,GetFoodDetail:i,AddToCart:n,GetUserCart:l,removeFromCart:async e=>await (0,s.WY)(a,c,{id:e})}},5821:(e,r,t)=>{"use strict";t.d(r,{default:()=>N});var s=t(326),a=t(7577),o=t(8307),d=t(7671),i=t(6226),n=t(772),l=t(5038),c=t(3162),m=t(4699);t(5098);var u=t(5999);let p=function({cart:e,setCart:r}){let{updateCart:t,setUpdateCart:a}=(0,c.mu)(),o=e=>{let r=(Array.isArray(e.addons)?e.addons:[{name:e.addons,price:e.addonsPrice}]).reduce((e,r)=>e+r.price,0);return Math.ceil(1.05*(e.price+r))},d=async r=>{try{await m.Z.removeFromCart(r),e.filter(e=>e.id!==r),a(!t),u.A.success("Item removed from cart")}catch(r){let e="Failed to remove item from cart";if(r.response&&r.response.errors){let t=r.response.errors.map(e=>e.message).join(", ");e+=`: ${t}`}else r.response&&401===r.response.status?e="Unauthorized error. Please check your API credentials.":r.response&&403===r.response.status?e="Authorization error. Please check your credentials.":console.error("Error:",r);u.A.error(e)}};return(0,s.jsxs)("div",{className:"",children:[s.jsx("div",{className:"mt-5",children:s.jsx("h2",{className:"font-bold text-lg",children:"My Order"})}),s.jsx("div",{className:"max-h-60 overflow-y-auto custom-scrollbar",children:e.length>0?e.map(e=>(0,s.jsxs)("div",{className:"flex mb-4 p-2 border rounded-lg items-center",children:[s.jsx("img",{src:e.productImage,alt:e.productName,className:"w-16 h-16 rounded-md"}),(0,s.jsxs)("div",{className:"ml-4 flex-grow",children:[s.jsx("h2",{className:"text-sm font-bold",children:e.productName}),(0,s.jsxs)("p",{className:"font-semibold text-sm",children:["Price: ₹ ",e.price.toFixed(2)]}),e.addons&&(0,s.jsxs)("div",{className:"mt-2",children:[s.jsx("h3",{className:"font-semibold text-sm",children:"Add-ons:"}),s.jsx("ul",{className:"text-sm list-inside",children:Array.isArray(e.addons)?e.addons.map(e=>(0,s.jsxs)("li",{children:[e.name," - ₹ ",e.price.toFixed(2)]},e.id)):(0,s.jsxs)("li",{children:[e.addons," - ₹ ",e.addonsPrice.toFixed(2)]})})]})]}),s.jsx("div",{className:"text-right",children:s.jsx("button",{className:"text-red-500 hover:text-red-700",onClick:()=>d(e?.id),children:"x"})})]},e.id)):s.jsx("p",{className:"text-center",children:"Your cart is empty."})}),e.length>0&&s.jsx("div",{className:"mt-4",children:(0,s.jsxs)("button",{className:"w-full bg-orange-500 text-white py-2 rounded-lg",children:["Checkout ₹ ",Math.ceil(e.reduce((e,r)=>e+parseFloat(o(r)),0))]})})]})};var g=t(9170),x=t(7863);let h=g.fC,f=g.xz,v=a.forwardRef(({className:e,align:r="center",sideOffset:t=4,...a},o)=>s.jsx(g.h_,{children:s.jsx(g.VY,{ref:o,align:r,sideOffset:t,className:(0,x.cn)("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",e),...a})}));v.displayName=g.VY.displayName;let b=function(){let{user:e,isSignedIn:r}=(0,l.aF)(),{updateCart:t,setUpdateCart:m}=(0,a.useContext)(c.Rm),[u,g]=(0,a.useState)([]);return(0,s.jsxs)("div",{className:"flex justify-between items-center p-6 md:px-20 shadow-sm",children:[s.jsx(i.default,{src:"/logo.png",alt:"logo",width:100,height:50}),(0,s.jsxs)("div",{className:"hidden md:flex border p-2 rounded-lg bg-gray-200 w-96",children:[s.jsx("input",{type:"text",className:"bg-transparent outline-none flex-grow",placeholder:"Search..."}),s.jsx(o.Z,{className:"ml-2 text-primary"})]}),r?(0,s.jsxs)("div",{className:"flex gap-3 items-center",children:[(0,s.jsxs)(h,{children:[s.jsx(f,{asChild:!0,children:(0,s.jsxs)("div",{className:"flex gap-2 items-center cursor-pointer",children:[s.jsx(d.Z,{}),s.jsx("label",{className:"p-1 px-3 rounded-full bg-slate-200",children:u?.length})]})}),s.jsx(v,{className:"bg-white ",children:s.jsx(p,{cart:u})})]}),s.jsx(l.l8,{})]}):(0,s.jsxs)("div",{className:"flex gap-5",children:[s.jsx(l.$d,{mode:"modal",children:s.jsx(n.z,{variant:"outline",className:"mr-2",children:"Login"})}),s.jsx(l.gX,{mode:"modal",children:s.jsx(n.z,{className:"bg-orange-500 text-white",children:"Signup"})})]})]})};var j=t(4831);let y=({...e})=>{let{theme:r="system"}=(0,j.F)();return s.jsx(u.x,{theme:r,className:"toaster group",toastOptions:{classNames:{toast:"group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",description:"group-[.toast]:text-muted-foreground",actionButton:"group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",cancelButton:"group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"}},...e})},N=({children:e})=>s.jsx(c.OG,{children:(0,s.jsxs)("div",{className:"px-10 md:px-20 relative",children:[s.jsx(b,{}),s.jsx(y,{}),e]})})},772:(e,r,t)=>{"use strict";t.d(r,{z:()=>l});var s=t(326),a=t(7577),o=t(4214),d=t(8671),i=t(7863);let n=(0,d.j)("inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",{variants:{variant:{default:"bg-primary text-primary-foreground hover:bg-primary/90",destructive:"bg-destructive text-destructive-foreground hover:bg-destructive/90",outline:"border border-input bg-background hover:bg-accent hover:text-accent-foreground",secondary:"bg-secondary text-secondary-foreground hover:bg-secondary/80",ghost:"hover:bg-accent hover:text-accent-foreground",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-10 px-4 py-2",sm:"h-9 rounded-md px-3",lg:"h-11 rounded-md px-8",icon:"h-10 w-10"}},defaultVariants:{variant:"default",size:"default"}}),l=a.forwardRef(({className:e,variant:r,size:t,asChild:a=!1,...d},l)=>{let c=a?o.g7:"button";return s.jsx(c,{className:(0,i.cn)(n({variant:r,size:t,className:e})),ref:l,...d})});l.displayName="Button"},7863:(e,r,t)=>{"use strict";t.d(r,{cn:()=>o});var s=t(1135),a=t(1009);function o(...e){return(0,a.m6)((0,s.W)(e))}},3904:(e,r,t)=>{"use strict";t.r(r),t.d(r,{default:()=>p,metadata:()=>u});var s=t(9510),a=t(7366),o=t.n(a);t(7272);var d=t(8570);let i=(0,d.createProxy)(String.raw`E:\e\fireaway\app\provider.tsx`),{__esModule:n,$$typeof:l}=i;i.default;let c=(0,d.createProxy)(String.raw`E:\e\fireaway\app\provider.tsx#default`);var m=t(1926);let u={title:"Create Next App",description:"Generated by create next app"};function p({children:e}){return s.jsx(m.El,{children:s.jsx("html",{lang:"en",children:(0,s.jsxs)("body",{className:o().className,children:[s.jsx(c,{children:e}),s.jsx(m.tj,{}),s.jsx(m.CH,{})]})})})}},5098:()=>{},7272:()=>{}};