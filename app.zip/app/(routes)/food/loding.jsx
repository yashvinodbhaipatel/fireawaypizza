import React from 'react'

function loding() {
  return (
    <div>
      loding...
    </div>
  )
}

export default loding
